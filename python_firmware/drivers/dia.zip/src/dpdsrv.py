#####################################################################
# Automatically generated file
# Don't edit this file
# Created on: 21 August 2014
#####################################################################

import sys, os 

print "Launching Dia framework ...\r\n"

if not os.path.isdir('/Users/lewiswight/MistAway-Gateway/Dia_2.1.0/'):
    execfile(os.path.join(os.path.abspath('.'), 'dia.py'))
else:
    execfile('/Users/lewiswight/MistAway-Gateway/Dia_2.1.0/dia.py')

